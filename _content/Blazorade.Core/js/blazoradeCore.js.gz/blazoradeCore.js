﻿
export function getClientTimezoneOffset() {
    return new Date().getTimezoneOffset();
}